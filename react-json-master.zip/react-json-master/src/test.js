import JSONViewer from './App';

describe('JSONViewer', () => {
    it('is truthy', () => {
        expect(JSONViewer).toBeTruthy();
    });
});